﻿namespace CommomLayer
{
    public class Class1
    {

    }
}
