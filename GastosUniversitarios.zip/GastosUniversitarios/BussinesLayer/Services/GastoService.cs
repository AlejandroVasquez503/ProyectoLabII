﻿using CommomLayer.Entities;
using DataAccessLayer.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLayer.Services
{
    public class GastoService
    {
        private GastoUniversitarioRepository _gastoUniversitarioRepository;

        public GastoService()
        {
            _gastoUniversitarioRepository = new GastoUniversitarioRepository();  // Instanciamos directamente el acceso a datos
        }

        public List<GastoUniversitario> GetAllGastos()
        {
            return _gastoUniversitarioRepository.GetAllGastos();
        }

        public GastoUniversitario GetGastoById(int id)
        {
            return _gastoUniversitarioRepository.GetGastoById(id);
        }

        public void AddGasto(GastoUniversitario gasto)
        {
            _gastoUniversitarioRepository.InsertGasto(gasto);
        }

        public void UpdateGasto(GastoUniversitario gasto)
        {
            _gastoUniversitarioRepository.UpdateGasto(gasto);
        }

        public void DeleteGasto(int id)
        {
            _gastoUniversitarioRepository.DeleteGasto(id);
        }
    }
}
