﻿using CommomLayer;
using CommomLayer.Entities;
using DataAccessLayer;
using DataAccessLayer.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLayer.Services
{
    public class UsuarioServices
    {
        private UsuarioRepository _usuarioRepository;
        public UsuarioServices()
        {
            _usuarioRepository = new UsuarioRepository();
        }

        public List<Usuario> GetAllUsuarios()
        {
            return _usuarioRepository.GetAllUsuarios(); // Llamada directa al método de la capa de datos
        }

        public Usuario GetUsuarioById(int id)
        {
            return _usuarioRepository.GetUsuarioById(id);
        }

        public void AddUsuario(Usuario usuario)
        {
            _usuarioRepository.InsertUsuario(usuario);
        }

        public void UpdateUsuario(Usuario usuario)
        {
            _usuarioRepository.UpdateUsuario(usuario);
        }

        public void DeleteUsuario(int id)
        {
            _usuarioRepository.DeleteUsuario(id);
        }
    }
}
