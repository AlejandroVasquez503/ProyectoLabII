﻿using CommomLayer.Entities;
using DataAccessLayer.DbConnection;
using DataAccessLayer.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLayer.Services
{
    public class CategoriaService
    {
        private  CategoriaGastoRepository _categoriaGastoRepository;

        public CategoriaService()
        {
            _categoriaGastoRepository = new CategoriaGastoRepository();  // Instanciamos directamente el acceso a datos
        }

        public List<CategoriaGasto> GetAllCategorias()
        {
            return _categoriaGastoRepository.GetAllCategorias();
        }

        public CategoriaGasto GetCategoriaById(int id)
        {
            return _categoriaGastoRepository.GetCategoriaById(id);
        }

        public void AddCategoria(CategoriaGasto categoria)
        {
            _categoriaGastoRepository.InsertCategoria(categoria);
        }

        public void UpdateCategoria(CategoriaGasto categoria)
        {
            _categoriaGastoRepository.UpdateCategoria(categoria);
        }

        public void DeleteCategoria(int id)
        {
            _categoriaGastoRepository.DeleteCategoria(id);
        }

        public List<KeyValuePair<int, string>> GetCategoriasParaComboBox()
        {
            var categorias = _categoriaGastoRepository.GetAllCategorias();
            return categorias.Select(c => new KeyValuePair<int, string>(c.IdCategoria, c.NombreCategoria)).ToList();
        }
    }
}
