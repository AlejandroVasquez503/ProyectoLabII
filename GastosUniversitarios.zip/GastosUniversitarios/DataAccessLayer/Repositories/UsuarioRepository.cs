﻿using CommomLayer.Entities;
using DataAccessLayer.DbConnection;
using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccessLayer.Repositories
{
    public class UsuarioRepository
    {
        private readonly SqlDataAccess _dbAccess;

        public UsuarioRepository()
        {
            _dbAccess = new SqlDataAccess();
        }

        public List<Usuario> GetAllUsuarios()
        {
            using (var connection = _dbAccess.GetconnectionBD())
            {
                connection.Open();
                var query = "SELECT * FROM Usuarios";
                var command = new SqlCommand(query, connection);
                var reader = command.ExecuteReader();
                var usuarios = new List<Usuario>();

                while (reader.Read())
                {
                    usuarios.Add(new Usuario
                    {
                        IdUsuario = (int)reader["IdUsuario"],
                        NombreUsuario = reader["NombreUsuario"].ToString(),
                        Apellido = reader["Apellido"].ToString(),
                        Carnet = reader["Carnet"].ToString(),
                        Contraseña = reader["Contraseña"].ToString()
                    });
                }
                return usuarios;
            }
        }

        public Usuario GetUsuarioById(int id)
        {
            using (var connection = _dbAccess.GetconnectionBD())
            {
                connection.Open();
                var query = "SELECT * FROM Usuarios WHERE IdUsuario = @IdUsuario";
                var command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@IdUsuario", id);
                var reader = command.ExecuteReader();

                if (reader.Read())
                {
                    return new Usuario
                    {
                        IdUsuario = (int)reader["IdUsuario"],
                        NombreUsuario = reader["NombreUsuario"].ToString(),
                        Apellido = reader["Apellido"].ToString(),
                        Carnet = reader["Carnet"].ToString(),
                        Contraseña = reader["Contraseña"].ToString()
                    };
                }
                return null;
            }
        }

        public void InsertUsuario(Usuario usuario)
        {
            using (var connection = _dbAccess.GetconnectionBD())
            {
                connection.Open();
                var query = "INSERT INTO Usuarios (NombreUsuario, Apellido, Carnet, Contraseña) VALUES (@NombreUsuario, @Apellido, @Carnet, @Contraseña)";
                var command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@NombreUsuario", usuario.NombreUsuario);
                command.Parameters.AddWithValue("@Apellido", usuario.Apellido);
                command.Parameters.AddWithValue("@Carnet", usuario.Carnet);
                command.Parameters.AddWithValue("@Contraseña", usuario.Contraseña);
                command.ExecuteNonQuery();
            }
        }

        public void UpdateUsuario(Usuario usuario)
        {
            using (var connection = _dbAccess.GetconnectionBD())
            {
                connection.Open();
                var query = "UPDATE Usuarios SET NombreUsuario = @NombreUsuario, Apellido = @Apellido, Carnet = @Carnet, Contraseña = @Contraseña WHERE IdUsuario = @IdUsuario";
                var command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@NombreUsuario", usuario.NombreUsuario);
                command.Parameters.AddWithValue("@Apellido", usuario.Apellido);
                command.Parameters.AddWithValue("@Carnet", usuario.Carnet);
                command.Parameters.AddWithValue("@Contraseña", usuario.Contraseña);
                command.Parameters.AddWithValue("@IdUsuario", usuario.IdUsuario);
                command.ExecuteNonQuery();
            }
        }

        public void DeleteUsuario(int id)
        {
            using (var connection = _dbAccess.GetconnectionBD())
            {
                connection.Open();
                var query = "DELETE FROM Usuarios WHERE IdUsuario = @IdUsuario";
                var command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@IdUsuario", id);
                command.ExecuteNonQuery();
            }
        }
    }
}
