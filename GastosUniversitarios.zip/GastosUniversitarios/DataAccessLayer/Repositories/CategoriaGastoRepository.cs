﻿using CommomLayer.Entities;
using DataAccessLayer.DbConnection;
using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccessLayer.Repositories
{
    public class CategoriaGastoRepository
    {
        private readonly SqlDataAccess _dbAccess;
        public CategoriaGastoRepository()
        {
            _dbAccess = new SqlDataAccess();
        }

        public List<CategoriaGasto> GetAllCategorias()
        {
            using (var connection = _dbAccess.GetconnectionBD())
            {
                connection.Open();
                var query = "SELECT * FROM CategoriasGasto";
                var command = new SqlCommand(query, connection);
                var reader = command.ExecuteReader();
                var categorias = new List<CategoriaGasto>();

                while (reader.Read())
                {
                    categorias.Add(new CategoriaGasto
                    {
                        IdCategoria = (int)reader["IdCategoria"],
                        NombreCategoria = reader["NombreCategoria"].ToString()
                    });
                }
                return categorias;
            }
        }

        public CategoriaGasto GetCategoriaById(int id)
        {
            using (var connection = _dbAccess.GetconnectionBD())
            {
                connection.Open();
                var query = "SELECT * FROM CategoriasGasto WHERE IdCategoria = @IdCategoria";
                var command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@IdCategoria", id);
                var reader = command.ExecuteReader();

                if (reader.Read())
                {
                    return new CategoriaGasto
                    {
                        IdCategoria = (int)reader["IdCategoria"],
                        NombreCategoria = reader["NombreCategoria"].ToString()
                    };
                }
                return null;
            }
        }

        public void InsertCategoria(CategoriaGasto categoria)
        {
            using (var connection = _dbAccess.GetconnectionBD())
            {
                connection.Open();
                var query = "INSERT INTO CategoriasGasto (NombreCategoria) VALUES (@NombreCategoria)";
                var command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@NombreCategoria", categoria.NombreCategoria);
                command.ExecuteNonQuery();
            }
        }

        public void UpdateCategoria(CategoriaGasto categoria)
        {
            using (var connection = _dbAccess.GetconnectionBD())
            {
                connection.Open();
                var query = "UPDATE CategoriasGasto SET NombreCategoria = @NombreCategoria WHERE IdCategoria = @IdCategoria";
                var command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@NombreCategoria", categoria.NombreCategoria);
                command.Parameters.AddWithValue("@IdCategoria", categoria.IdCategoria);
                command.ExecuteNonQuery();
            }
        }

        public void DeleteCategoria(int id)
        {
            using (var connection = _dbAccess.GetconnectionBD())
            {
                connection.Open();
                var query = "DELETE FROM CategoriasGasto WHERE IdCategoria = @IdCategoria";
                var command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@IdCategoria", id);
                command.ExecuteNonQuery();
            }
        }
    }
}
