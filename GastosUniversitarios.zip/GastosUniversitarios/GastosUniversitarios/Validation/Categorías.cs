﻿using FluentValidation;
using CommomLayer.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PresentationLayer.Validations
{
    public class Categorías : AbstractValidator<CategoriaGasto>
    {
        public Categorías()
        {
            RuleFor(categoria => categoria.NombreCategoria)
                .NotEmpty().WithMessage("El nombre de la categoría es requerido")
                .MinimumLength(3).WithMessage("El nombre de la categoría debe tener al menos 3 caracteres");

            // Validación adicional para evitar nombres de categoría duplicados
            RuleFor(categoria => categoria.NombreCategoria)
                .Matches(@"^[a-zA-Z\s]+$").WithMessage("El nombre de la categoría solo puede contener letras y espacios");
        }
    }
}
