﻿namespace GastosUniversitarios.Forms
{
    partial class CategoriasForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnGuardarCategoria = new Button();
            cmbCategoria = new ComboBox();
            labelCategoria = new Label();
            SuspendLayout();
            // 
            // btnGuardarCategoria
            // 
            btnGuardarCategoria.Font = new Font("Segoe UI", 10.8F, FontStyle.Italic, GraphicsUnit.Point, 0);
            btnGuardarCategoria.Location = new Point(179, 141);
            btnGuardarCategoria.Name = "btnGuardarCategoria";
            btnGuardarCategoria.Size = new Size(180, 51);
            btnGuardarCategoria.TabIndex = 5;
            btnGuardarCategoria.Text = "Guardar Categoria";
            btnGuardarCategoria.UseVisualStyleBackColor = true;
            btnGuardarCategoria.Click += btnGuardarCategoria_Click;
            // 
            // cmbCategoria
            // 
            cmbCategoria.FormattingEnabled = true;
            cmbCategoria.Items.AddRange(new object[] { "Comida ", "Materiales", "Matricula ", "Transporte" });
            cmbCategoria.Location = new Point(109, 94);
            cmbCategoria.Name = "cmbCategoria";
            cmbCategoria.Size = new Size(306, 28);
            cmbCategoria.TabIndex = 4;
            // 
            // labelCategoria
            // 
            labelCategoria.AutoSize = true;
            labelCategoria.Font = new Font("Segoe UI", 13.8F, FontStyle.Italic, GraphicsUnit.Point, 0);
            labelCategoria.Location = new Point(147, 40);
            labelCategoria.Name = "labelCategoria";
            labelCategoria.Size = new Size(236, 31);
            labelCategoria.TabIndex = 3;
            labelCategoria.Text = "Agregue una categoria";
            // 
            // CategoriasForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(510, 228);
            Controls.Add(btnGuardarCategoria);
            Controls.Add(cmbCategoria);
            Controls.Add(labelCategoria);
            Name = "CategoriasForm";
            Text = "CategoriasForm";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnGuardarCategoria;
        private ComboBox cmbCategoria;
        private Label labelCategoria;
    }
}