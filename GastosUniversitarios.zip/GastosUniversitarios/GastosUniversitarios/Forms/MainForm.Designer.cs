﻿namespace GastosUniversitarios.Forms
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            labelIngresarUsuarios = new Label();
            groupBoxUsuario = new GroupBox();
            txtContraseña = new TextBox();
            txtCarnet = new TextBox();
            txtApellido = new TextBox();
            txtNombreUsuario = new TextBox();
            labelContraseña = new Label();
            labelCarnet = new Label();
            labelLastName = new Label();
            labelName = new Label();
            btnAgregarUsuario = new Button();
            dgvUsuarios = new DataGridView();
            groupBoxUsuario.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgvUsuarios).BeginInit();
            SuspendLayout();
            // 
            // labelIngresarUsuarios
            // 
            labelIngresarUsuarios.AutoSize = true;
            labelIngresarUsuarios.Font = new Font("Segoe UI", 13.8F, FontStyle.Italic, GraphicsUnit.Point, 0);
            labelIngresarUsuarios.Location = new Point(416, 9);
            labelIngresarUsuarios.Name = "labelIngresarUsuarios";
            labelIngresarUsuarios.Size = new Size(198, 31);
            labelIngresarUsuarios.TabIndex = 0;
            labelIngresarUsuarios.Text = "Ingrese un Usuario";
            // 
            // groupBoxUsuario
            // 
            groupBoxUsuario.Controls.Add(txtContraseña);
            groupBoxUsuario.Controls.Add(txtCarnet);
            groupBoxUsuario.Controls.Add(txtApellido);
            groupBoxUsuario.Controls.Add(txtNombreUsuario);
            groupBoxUsuario.Controls.Add(labelContraseña);
            groupBoxUsuario.Controls.Add(labelCarnet);
            groupBoxUsuario.Controls.Add(labelLastName);
            groupBoxUsuario.Controls.Add(labelName);
            groupBoxUsuario.Location = new Point(53, 97);
            groupBoxUsuario.Name = "groupBoxUsuario";
            groupBoxUsuario.Size = new Size(1007, 298);
            groupBoxUsuario.TabIndex = 1;
            groupBoxUsuario.TabStop = false;
            groupBoxUsuario.Text = "Formulario";
            // 
            // txtContraseña
            // 
            txtContraseña.Location = new Point(579, 229);
            txtContraseña.Name = "txtContraseña";
            txtContraseña.Size = new Size(352, 27);
            txtContraseña.TabIndex = 9;
            // 
            // txtCarnet
            // 
            txtCarnet.Location = new Point(579, 99);
            txtCarnet.Name = "txtCarnet";
            txtCarnet.Size = new Size(352, 27);
            txtCarnet.TabIndex = 8;
            // 
            // txtApellido
            // 
            txtApellido.Location = new Point(25, 229);
            txtApellido.Name = "txtApellido";
            txtApellido.Size = new Size(352, 27);
            txtApellido.TabIndex = 7;
            // 
            // txtNombreUsuario
            // 
            txtNombreUsuario.Location = new Point(25, 99);
            txtNombreUsuario.Name = "txtNombreUsuario";
            txtNombreUsuario.Size = new Size(352, 27);
            txtNombreUsuario.TabIndex = 6;
            // 
            // labelContraseña
            // 
            labelContraseña.AutoSize = true;
            labelContraseña.Font = new Font("Segoe UI", 10.8F, FontStyle.Italic, GraphicsUnit.Point, 0);
            labelContraseña.Location = new Point(579, 175);
            labelContraseña.Name = "labelContraseña";
            labelContraseña.Size = new Size(102, 25);
            labelContraseña.TabIndex = 5;
            labelContraseña.Text = "Contraseña";
            // 
            // labelCarnet
            // 
            labelCarnet.AutoSize = true;
            labelCarnet.Font = new Font("Segoe UI", 10.8F, FontStyle.Italic, GraphicsUnit.Point, 0);
            labelCarnet.Location = new Point(579, 48);
            labelCarnet.Name = "labelCarnet";
            labelCarnet.Size = new Size(65, 25);
            labelCarnet.TabIndex = 4;
            labelCarnet.Text = "Carnet";
            // 
            // labelLastName
            // 
            labelLastName.AutoSize = true;
            labelLastName.Font = new Font("Segoe UI", 10.8F, FontStyle.Italic, GraphicsUnit.Point, 0);
            labelLastName.Location = new Point(25, 175);
            labelLastName.Name = "labelLastName";
            labelLastName.Size = new Size(77, 25);
            labelLastName.TabIndex = 3;
            labelLastName.Text = "Apellido";
            // 
            // labelName
            // 
            labelName.AutoSize = true;
            labelName.Font = new Font("Segoe UI", 10.8F, FontStyle.Italic, GraphicsUnit.Point, 0);
            labelName.Location = new Point(25, 48);
            labelName.Name = "labelName";
            labelName.Size = new Size(76, 25);
            labelName.TabIndex = 2;
            labelName.Text = "Nombre";
            // 
            // btnAgregarUsuario
            // 
            btnAgregarUsuario.Font = new Font("Segoe UI", 10.8F, FontStyle.Italic, GraphicsUnit.Point, 0);
            btnAgregarUsuario.Location = new Point(471, 410);
            btnAgregarUsuario.Name = "btnAgregarUsuario";
            btnAgregarUsuario.Size = new Size(105, 39);
            btnAgregarUsuario.TabIndex = 2;
            btnAgregarUsuario.Text = "Agregar";
            btnAgregarUsuario.UseVisualStyleBackColor = true;
            btnAgregarUsuario.Click += btnAgregarUsuario_Click;
            // 
            // dgvUsuarios
            // 
            dgvUsuarios.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvUsuarios.Location = new Point(53, 466);
            dgvUsuarios.Name = "dgvUsuarios";
            dgvUsuarios.RowHeadersWidth = 51;
            dgvUsuarios.Size = new Size(1007, 235);
            dgvUsuarios.TabIndex = 3;
            // 
            // MainForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1191, 746);
            Controls.Add(dgvUsuarios);
            Controls.Add(btnAgregarUsuario);
            Controls.Add(groupBoxUsuario);
            Controls.Add(labelIngresarUsuarios);
            Name = "MainForm";
            Text = "MainForm";
            groupBoxUsuario.ResumeLayout(false);
            groupBoxUsuario.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dgvUsuarios).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label labelIngresarUsuarios;
        private GroupBox groupBoxUsuario;
        private Label labelContraseña;
        private Label labelCarnet;
        private Label labelLastName;
        private Label labelName;
        private TextBox txtContraseña;
        private TextBox txtCarnet;
        private TextBox txtApellido;
        private TextBox txtNombreUsuario;
        private Button btnAgregarUsuario;
        private DataGridView dgvUsuarios;
    }
}