﻿namespace GastosUniversitarios.Forms
{
    partial class GastosForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            labelEditarGastos = new Label();
            labelMonto = new Label();
            groupBox1 = new GroupBox();
            dtpFecha = new DateTimePicker();
            labelFecha = new Label();
            txtDescripcion = new TextBox();
            labelDescripción = new Label();
            labelUsuario = new Label();
            cmbUsuario = new ComboBox();
            cmbCategoria = new ComboBox();
            labelCategoria = new Label();
            txtMonto = new TextBox();
            btnAgregar = new Button();
            btnEditar = new Button();
            btnEliminar = new Button();
            dgvGastos = new DataGridView();
            groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgvGastos).BeginInit();
            SuspendLayout();
            // 
            // labelEditarGastos
            // 
            labelEditarGastos.AutoSize = true;
            labelEditarGastos.Font = new Font("Segoe UI", 13.8F, FontStyle.Italic, GraphicsUnit.Point, 0);
            labelEditarGastos.Location = new Point(471, 24);
            labelEditarGastos.Name = "labelEditarGastos";
            labelEditarGastos.Size = new Size(141, 31);
            labelEditarGastos.TabIndex = 0;
            labelEditarGastos.Text = "Editar Gastos";
            // 
            // labelMonto
            // 
            labelMonto.AutoSize = true;
            labelMonto.Font = new Font("Segoe UI", 10.8F, FontStyle.Italic, GraphicsUnit.Point, 0);
            labelMonto.Location = new Point(33, 58);
            labelMonto.Name = "labelMonto";
            labelMonto.Size = new Size(63, 25);
            labelMonto.TabIndex = 1;
            labelMonto.Text = "Monto";
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(dtpFecha);
            groupBox1.Controls.Add(labelFecha);
            groupBox1.Controls.Add(txtDescripcion);
            groupBox1.Controls.Add(labelDescripción);
            groupBox1.Controls.Add(labelUsuario);
            groupBox1.Controls.Add(cmbUsuario);
            groupBox1.Controls.Add(cmbCategoria);
            groupBox1.Controls.Add(labelCategoria);
            groupBox1.Controls.Add(txtMonto);
            groupBox1.Controls.Add(labelMonto);
            groupBox1.Location = new Point(84, 71);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(993, 329);
            groupBox1.TabIndex = 2;
            groupBox1.TabStop = false;
            groupBox1.Text = "groupBox1";
            // 
            // dtpFecha
            // 
            dtpFecha.Location = new Point(115, 272);
            dtpFecha.Name = "dtpFecha";
            dtpFecha.Size = new Size(287, 27);
            dtpFecha.TabIndex = 10;
            // 
            // labelFecha
            // 
            labelFecha.AutoSize = true;
            labelFecha.Font = new Font("Segoe UI", 10.8F, FontStyle.Italic, GraphicsUnit.Point, 0);
            labelFecha.Location = new Point(33, 272);
            labelFecha.Name = "labelFecha";
            labelFecha.Size = new Size(58, 25);
            labelFecha.TabIndex = 9;
            labelFecha.Text = "Fecha";
            // 
            // txtDescripcion
            // 
            txtDescripcion.Location = new Point(133, 184);
            txtDescripcion.Name = "txtDescripcion";
            txtDescripcion.Size = new Size(287, 27);
            txtDescripcion.TabIndex = 8;
            // 
            // labelDescripción
            // 
            labelDescripción.AutoSize = true;
            labelDescripción.Font = new Font("Segoe UI", 10.8F, FontStyle.Italic, GraphicsUnit.Point, 0);
            labelDescripción.Location = new Point(24, 184);
            labelDescripción.Name = "labelDescripción";
            labelDescripción.Size = new Size(103, 25);
            labelDescripción.TabIndex = 7;
            labelDescripción.Text = "Descripción";
            // 
            // labelUsuario
            // 
            labelUsuario.AutoSize = true;
            labelUsuario.Font = new Font("Segoe UI", 10.8F, FontStyle.Italic, GraphicsUnit.Point, 0);
            labelUsuario.Location = new Point(490, 179);
            labelUsuario.Name = "labelUsuario";
            labelUsuario.Size = new Size(72, 25);
            labelUsuario.TabIndex = 6;
            labelUsuario.Text = "Usuario";
            // 
            // cmbUsuario
            // 
            cmbUsuario.FormattingEnabled = true;
            cmbUsuario.Location = new Point(595, 180);
            cmbUsuario.Name = "cmbUsuario";
            cmbUsuario.Size = new Size(354, 28);
            cmbUsuario.TabIndex = 5;
            // 
            // cmbCategoria
            // 
            cmbCategoria.FormattingEnabled = true;
            cmbCategoria.Items.AddRange(new object[] { "Comida ", "Materiales", "Matricula ", "Transporte" });
            cmbCategoria.Location = new Point(595, 62);
            cmbCategoria.Name = "cmbCategoria";
            cmbCategoria.Size = new Size(354, 28);
            cmbCategoria.TabIndex = 4;
            // 
            // labelCategoria
            // 
            labelCategoria.AutoSize = true;
            labelCategoria.Font = new Font("Segoe UI", 10.8F, FontStyle.Italic, GraphicsUnit.Point, 0);
            labelCategoria.Location = new Point(490, 61);
            labelCategoria.Name = "labelCategoria";
            labelCategoria.Size = new Size(90, 25);
            labelCategoria.TabIndex = 3;
            labelCategoria.Text = "Categoria";
            // 
            // txtMonto
            // 
            txtMonto.Location = new Point(115, 59);
            txtMonto.Name = "txtMonto";
            txtMonto.Size = new Size(287, 27);
            txtMonto.TabIndex = 2;
            // 
            // btnAgregar
            // 
            btnAgregar.Font = new Font("Segoe UI", 10.8F, FontStyle.Italic, GraphicsUnit.Point, 0);
            btnAgregar.Location = new Point(117, 420);
            btnAgregar.Name = "btnAgregar";
            btnAgregar.Size = new Size(112, 43);
            btnAgregar.TabIndex = 11;
            btnAgregar.Text = "Agregar";
            btnAgregar.UseVisualStyleBackColor = true;
            btnAgregar.Click += btnAgregar_Click;
            // 
            // btnEditar
            // 
            btnEditar.Font = new Font("Segoe UI", 10.8F, FontStyle.Italic, GraphicsUnit.Point, 0);
            btnEditar.Location = new Point(518, 420);
            btnEditar.Name = "btnEditar";
            btnEditar.Size = new Size(110, 43);
            btnEditar.TabIndex = 12;
            btnEditar.Text = "Editar";
            btnEditar.UseVisualStyleBackColor = true;
            btnEditar.Click += btnEditar_Click;
            // 
            // btnEliminar
            // 
            btnEliminar.Font = new Font("Segoe UI", 10.8F, FontStyle.Italic, GraphicsUnit.Point, 0);
            btnEliminar.Location = new Point(852, 420);
            btnEliminar.Name = "btnEliminar";
            btnEliminar.Size = new Size(114, 43);
            btnEliminar.TabIndex = 13;
            btnEliminar.Text = "Eliminar";
            btnEliminar.UseVisualStyleBackColor = true;
            btnEliminar.Click += btnEliminar_Click;
            // 
            // dgvGastos
            // 
            dgvGastos.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvGastos.Location = new Point(84, 469);
            dgvGastos.Name = "dgvGastos";
            dgvGastos.RowHeadersWidth = 51;
            dgvGastos.Size = new Size(993, 233);
            dgvGastos.TabIndex = 14;
            dgvGastos.SelectionChanged += dgvGastos_SelectionChanged;
            // 
            // GastosForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1187, 731);
            Controls.Add(dgvGastos);
            Controls.Add(btnEliminar);
            Controls.Add(btnEditar);
            Controls.Add(btnAgregar);
            Controls.Add(groupBox1);
            Controls.Add(labelEditarGastos);
            Name = "GastosForm";
            Text = "GastosForm";
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dgvGastos).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label labelEditarGastos;
        private Label labelMonto;
        private GroupBox groupBox1;
        private TextBox txtDescripcion;
        private Label labelDescripción;
        private Label labelUsuario;
        private ComboBox cmbUsuario;
        private ComboBox cmbCategoria;
        private Label labelCategoria;
        private TextBox txtMonto;
        private DateTimePicker dtpFecha;
        private Label labelFecha;
        private Button btnAgregar;
        private Button btnEditar;
        private Button btnEliminar;
        private DataGridView dgvGastos;
    }
}