﻿using BusinessLayer.Services;
using CommomLayer.Entities;
using PresentationLayer.Validations;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GastosUniversitarios.Forms
{
    public partial class CategoriasForm : Form
    {
        private CategoriaService _categoriasService;
        private CategoriaGasto _categoria;
        public CategoriasForm()
        {
            InitializeComponent();
            _categoriasService = new CategoriaService();

            cmbCategoria.Items.Add("Materiales");
            cmbCategoria.Items.Add("Comida");
            cmbCategoria.Items.Add("Matrícula");
            cmbCategoria.Items.Add("Transporte");
        }

        private void btnGuardarCategoria_Click(object sender, EventArgs e)
        {
            if (ValidateForm())
            {
                _categoria = new CategoriaGasto
                {
                    NombreCategoria = cmbCategoria.SelectedItem.ToString()
                };

                _categoriasService.AddCategoria(_categoria);

                MessageBox.Show("Categoría agregada con éxito.", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }


        }

        private bool ValidateForm()
        {
            if (cmbCategoria.SelectedItem == null)
            {
                MessageBox.Show("Debe seleccionar una categoría.", "Error de validación", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }

            return true;
        }
    }
}
