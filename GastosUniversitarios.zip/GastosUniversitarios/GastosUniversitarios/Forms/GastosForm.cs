﻿using BusinessLayer.Services;
using CommomLayer.Entities;
using PresentationLayer.Validations;
using FluentValidation;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using FluentValidation.Results;

namespace GastosUniversitarios.Forms
{
    public partial class GastosForm : Form
    {
        private GastoService _gastoService;
        private GastoUniversitario _gastoSeleccionado;
        private CategoriaService _categoriaService;
        private UsuarioServices _usuarioServices;
        public GastosForm()
        {
            InitializeComponent();
            _gastoService = new GastoService();
            _categoriaService = new CategoriaService();
            _usuarioServices = new UsuarioServices();
            LoadFormData();
        }

        private void LoadFormData()
        {
            LoadGastos();
            CargarCategorias();
            CargarUsuarios();
        }

        private void LoadGastos()
        {
            dgvGastos.DataSource = _gastoService.GetAllGastos();
            dgvGastos.ClearSelection();
        }

        private void CargarCategorias()
        {
            var categorias = _categoriaService.GetAllCategorias();
            cmbCategoria.DataSource = categorias;
            cmbCategoria.DisplayMember = "NombreCategoria";
            cmbCategoria.ValueMember = "IdCategoria";
        }

        private void CargarUsuarios()
        {
            var usuarios = _usuarioServices.GetAllUsuarios();
            cmbUsuario.DataSource = usuarios;
            cmbUsuario.DisplayMember = "NombreUsuario";
            cmbUsuario.ValueMember = "IdUsuario";
        }

        private void dgvGastos_SelectionChanged(object sender, EventArgs e)
        {
            if (dgvGastos.SelectedRows.Count > 0)
            {
                var selectedRow = dgvGastos.SelectedRows[0];
                _gastoSeleccionado = (GastoUniversitario)selectedRow.DataBoundItem;

                dtpFecha.Value = _gastoSeleccionado.Fecha;
                txtMonto.Text = _gastoSeleccionado.Monto.ToString();
                txtDescripcion.Text = _gastoSeleccionado.Descripcion;
                cmbCategoria.SelectedValue = _gastoSeleccionado.IdCategoria;
                cmbUsuario.SelectedValue = _gastoSeleccionado.IdUsuario;
            }
        }

        private void btnAgregar_Click(object sender, EventArgs e)
        {
            GastoUniversitario nuevoGasto = new GastoUniversitario
            {
                Fecha = dtpFecha.Value,
                Monto = Convert.ToDecimal(txtMonto.Text),
                Descripcion = txtDescripcion.Text,
                IdCategoria = Convert.ToInt32(cmbCategoria.SelectedValue),
                IdUsuario = Convert.ToInt32(cmbUsuario.SelectedValue)
            };

            GastosUniversitariosValidator validator = new GastosUniversitariosValidator();
            ValidationResult resultadoValidacion = validator.Validate(nuevoGasto);

            if (resultadoValidacion.IsValid)
            {
                _gastoService.AddGasto(nuevoGasto);
                MessageBox.Show("Gasto agregado exitosamente");
                LoadGastos();
            }
            else
            {
                MessageBox.Show(string.Join(Environment.NewLine, resultadoValidacion.Errors.Select(e => e.ErrorMessage)));
            }
        }

        private void btnEditar_Click(object sender, EventArgs e)
        {
            if (_gastoSeleccionado != null)
            {
                _gastoSeleccionado.Fecha = dtpFecha.Value;
                _gastoSeleccionado.Monto = Convert.ToDecimal(txtMonto.Text);
                _gastoSeleccionado.Descripcion = txtDescripcion.Text;
                _gastoSeleccionado.IdCategoria = Convert.ToInt32(cmbCategoria.SelectedValue);
                _gastoSeleccionado.IdUsuario = Convert.ToInt32(cmbUsuario.SelectedValue);

                GastosUniversitariosValidator validator = new GastosUniversitariosValidator();
                ValidationResult resultadoValidacion = validator.Validate(_gastoSeleccionado);

                if (resultadoValidacion.IsValid)
                {
                    _gastoService.UpdateGasto(_gastoSeleccionado);
                    MessageBox.Show("Gasto editado exitosamente");
                    LoadGastos();
                }
                else
                {
                    MessageBox.Show(string.Join(Environment.NewLine, resultadoValidacion.Errors.Select(e => e.ErrorMessage)));
                }
            }
            else
            {
                MessageBox.Show("Por favor seleccione un gasto para editar.");
            }
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            if (_gastoSeleccionado != null)
            {
                var dialogResult = MessageBox.Show("¿Está seguro de que desea eliminar este gasto?", "Confirmar eliminación", MessageBoxButtons.YesNo);
                if (dialogResult == DialogResult.Yes)
                {
                    _gastoService.DeleteGasto(_gastoSeleccionado.IdGasto);
                    MessageBox.Show("Gasto eliminado exitosamente");
                    LoadGastos();
                }
            }
            else
            {
                MessageBox.Show("Por favor seleccione un gasto para eliminar.");
            }
        }


    }
}
