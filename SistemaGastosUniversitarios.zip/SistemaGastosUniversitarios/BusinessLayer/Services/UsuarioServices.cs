﻿using CommomLayer;
using CommomLayer.Entities;
using DataAccessLayer;
using DataAccessLayer.DbConnection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLayer.Services
{
    public class UsuarioServices
    {
        private SqlDataAccess _dataAccess;
        public UsuarioServices()
        {
            _dataAccess = new SqlDataAccess();
        }

        public List<Usuario> GetAllUsuarios()
        {
            return _dataAccess.GetUsuarios(); // Llamada directa al método de la capa de datos
        }

        public Usuario GetUsuarioById(int id)
        {
            return _dataAccess.GetUsuarioById(id);
        }

        public void AddUsuario(Usuario usuario)
        {
            _dataAccess.InsertUsuario(usuario);
        }

        public void UpdateUsuario(Usuario usuario)
        {
            _dataAccess.UpdateUsuario(usuario);
        }

        public void DeleteUsuario(int id)
        {
            _dataAccess.DeleteUsuario(id);
        }
    }
}
