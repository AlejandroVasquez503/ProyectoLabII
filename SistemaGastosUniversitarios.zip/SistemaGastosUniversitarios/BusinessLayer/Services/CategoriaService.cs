﻿using CommomLayer.Entities;
using DataAccessLayer.DbConnection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLayer.Services
{
    public class CategoriaService
    {
        private SqlDataAccess _dataAccess;

        public CategoriaService()
        {
            _dataAccess = new SqlDataAccess();  // Instanciamos directamente el acceso a datos
        }

        public List<CategoriaGasto> GetAllCategorias()
        {
            return _dataAccess.GetCategorias();
        }

        public CategoriaGasto GetCategoriaById(int id)
        {
            return _dataAccess.GetCategoriaById(id);
        }

        public void AddCategoria(CategoriaGasto categoria)
        {
            _dataAccess.InsertCategoria(categoria);
        }

        public void UpdateCategoria(CategoriaGasto categoria)
        {
            _dataAccess.UpdateCategoria(categoria);
        }

        public void DeleteCategoria(int id)
        {
            _dataAccess.DeleteCategoria(id);
        }

        public List<KeyValuePair<int, string>> GetCategoriasParaComboBox()
        {
            var categorias = _dataAccess.GetAllCategorias();
            return categorias.Select(c => new KeyValuePair<int, string>(c.IdCategoria, c.NombreCategoria)).ToList();
        }
    }
}
