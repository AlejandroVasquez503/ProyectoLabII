﻿using CommomLayer.Entities;
using DataAccessLayer.DbConnection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLayer.Services
{
    public class GastoService
    {
        private SqlDataAccess _dataAccess;

        public GastoService()
        {
            _dataAccess = new SqlDataAccess();  // Instanciamos directamente el acceso a datos
        }

        public List<GastoUniversitario> GetAllGastos()
        {
            return _dataAccess.GetGastos();
        }

        public GastoUniversitario GetGastoById(int id)
        {
            return _dataAccess.GetGastoById(id);
        }

        public void AddGasto(GastoUniversitario gasto)
        {
            _dataAccess.InsertGasto(gasto);
        }

        public void UpdateGasto(GastoUniversitario gasto)
        {
            _dataAccess.UpdateGasto(gasto);
        }

        public void DeleteGasto(int id)
        {
            _dataAccess.DeleteGasto(id);
        }
    }
}
