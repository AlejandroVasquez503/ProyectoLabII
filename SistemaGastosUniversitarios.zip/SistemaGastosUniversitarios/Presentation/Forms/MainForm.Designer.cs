﻿namespace PresentationLayer.Forms
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            label1 = new Label();
            DataGridViewUsuario = new GroupBox();
            txtContraseña = new TextBox();
            txtCarnet = new TextBox();
            txtApellido = new TextBox();
            txtNombreUsuario = new TextBox();
            labelContraseña = new Label();
            labelCarnet = new Label();
            labelApellido = new Label();
            LabelNombre = new Label();
            btnAgregarUsuario = new Button();
            dgvUsuarios = new DataGridView();
            errorProviderUsuario = new ErrorProvider(components);
            DataGridViewUsuario.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgvUsuarios).BeginInit();
            ((System.ComponentModel.ISupportInitialize)errorProviderUsuario).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI Semibold", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(462, 9);
            label1.Name = "label1";
            label1.Size = new Size(203, 31);
            label1.TabIndex = 0;
            label1.Text = "Ingrese su usuario";
            // 
            // DataGridViewUsuario
            // 
            DataGridViewUsuario.Controls.Add(txtContraseña);
            DataGridViewUsuario.Controls.Add(txtCarnet);
            DataGridViewUsuario.Controls.Add(txtApellido);
            DataGridViewUsuario.Controls.Add(txtNombreUsuario);
            DataGridViewUsuario.Controls.Add(labelContraseña);
            DataGridViewUsuario.Controls.Add(labelCarnet);
            DataGridViewUsuario.Controls.Add(labelApellido);
            DataGridViewUsuario.Controls.Add(LabelNombre);
            DataGridViewUsuario.Location = new Point(110, 94);
            DataGridViewUsuario.Name = "DataGridViewUsuario";
            DataGridViewUsuario.Size = new Size(951, 290);
            DataGridViewUsuario.TabIndex = 1;
            DataGridViewUsuario.TabStop = false;
            DataGridViewUsuario.Text = "Formulario";
            // 
            // txtContraseña
            // 
            txtContraseña.Location = new Point(470, 198);
            txtContraseña.Name = "txtContraseña";
            txtContraseña.Size = new Size(350, 27);
            txtContraseña.TabIndex = 7;
            // 
            // txtCarnet
            // 
            txtCarnet.Location = new Point(470, 89);
            txtCarnet.Name = "txtCarnet";
            txtCarnet.Size = new Size(350, 27);
            txtCarnet.TabIndex = 6;
            // 
            // txtApellido
            // 
            txtApellido.Location = new Point(18, 198);
            txtApellido.Name = "txtApellido";
            txtApellido.Size = new Size(350, 27);
            txtApellido.TabIndex = 5;
            // 
            // txtNombreUsuario
            // 
            txtNombreUsuario.Location = new Point(18, 89);
            txtNombreUsuario.Name = "txtNombreUsuario";
            txtNombreUsuario.Size = new Size(350, 27);
            txtNombreUsuario.TabIndex = 4;
            // 
            // labelContraseña
            // 
            labelContraseña.AutoSize = true;
            labelContraseña.Font = new Font("Segoe UI", 10.8F, FontStyle.Italic, GraphicsUnit.Point, 0);
            labelContraseña.Location = new Point(479, 148);
            labelContraseña.Name = "labelContraseña";
            labelContraseña.Size = new Size(102, 25);
            labelContraseña.TabIndex = 3;
            labelContraseña.Text = "Contraseña";
            // 
            // labelCarnet
            // 
            labelCarnet.AutoSize = true;
            labelCarnet.Font = new Font("Segoe UI", 10.8F, FontStyle.Italic, GraphicsUnit.Point, 0);
            labelCarnet.Location = new Point(479, 35);
            labelCarnet.Name = "labelCarnet";
            labelCarnet.Size = new Size(65, 25);
            labelCarnet.TabIndex = 2;
            labelCarnet.Text = "Carnet";
            // 
            // labelApellido
            // 
            labelApellido.AutoSize = true;
            labelApellido.Font = new Font("Segoe UI", 10.8F, FontStyle.Italic, GraphicsUnit.Point, 0);
            labelApellido.Location = new Point(29, 148);
            labelApellido.Name = "labelApellido";
            labelApellido.Size = new Size(77, 25);
            labelApellido.TabIndex = 1;
            labelApellido.Text = "Apellido";
            // 
            // LabelNombre
            // 
            LabelNombre.AutoSize = true;
            LabelNombre.Font = new Font("Segoe UI", 10.8F, FontStyle.Italic, GraphicsUnit.Point, 0);
            LabelNombre.Location = new Point(30, 45);
            LabelNombre.Name = "LabelNombre";
            LabelNombre.Size = new Size(76, 25);
            LabelNombre.TabIndex = 0;
            LabelNombre.Text = "Nombre";
            // 
            // btnAgregarUsuario
            // 
            btnAgregarUsuario.Font = new Font("Segoe UI", 10.8F, FontStyle.Italic, GraphicsUnit.Point, 0);
            btnAgregarUsuario.Location = new Point(491, 390);
            btnAgregarUsuario.Name = "btnAgregarUsuario";
            btnAgregarUsuario.Size = new Size(111, 35);
            btnAgregarUsuario.TabIndex = 8;
            btnAgregarUsuario.Text = "Agregar";
            btnAgregarUsuario.UseVisualStyleBackColor = true;
            btnAgregarUsuario.Click += btnAgregarUsuario_Click;
            // 
            // dgvUsuarios
            // 
            dgvUsuarios.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvUsuarios.Location = new Point(92, 441);
            dgvUsuarios.Name = "dgvUsuarios";
            dgvUsuarios.RowHeadersWidth = 51;
            dgvUsuarios.Size = new Size(969, 209);
            dgvUsuarios.TabIndex = 9;
            // 
            // errorProviderUsuario
            // 
            errorProviderUsuario.ContainerControl = this;
            // 
            // MainForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1180, 694);
            Controls.Add(dgvUsuarios);
            Controls.Add(btnAgregarUsuario);
            Controls.Add(DataGridViewUsuario);
            Controls.Add(label1);
            Name = "MainForm";
            Text = "MainForm";
            DataGridViewUsuario.ResumeLayout(false);
            DataGridViewUsuario.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dgvUsuarios).EndInit();
            ((System.ComponentModel.ISupportInitialize)errorProviderUsuario).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private GroupBox DataGridViewUsuario;
        private TextBox txtContraseña;
        private TextBox txtCarnet;
        private TextBox txtApellido;
        private TextBox txtNombreUsuario;
        private Label labelContraseña;
        private Label labelCarnet;
        private Label labelApellido;
        private Label LabelNombre;
        private Button btnAgregarUsuario;
        private DataGridView dgvUsuarios;
        private ErrorProvider errorProviderUsuario;
    }
}