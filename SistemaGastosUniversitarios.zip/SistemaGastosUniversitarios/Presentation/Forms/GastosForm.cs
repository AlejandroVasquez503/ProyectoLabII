﻿using BusinessLayer.Services;
using CommomLayer.Entities;
using PresentationLayer.Validations;
using FluentValidation.Results;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PresentationLayer.Forms
{
    public partial class GastosForm : Form
    {
        public GastosForm()
        {
            InitializeComponent();
        }
    }
}
