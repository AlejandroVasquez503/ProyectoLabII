﻿using BusinessLayer.Services;
using CommomLayer.Entities;
using PresentationLayer.Validations;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PresentationLayer.Forms
{
    public partial class MainForm : Form
    {
        private UsuarioServices _usuarioServices;
        private UsuarioValidator _usuarioValidator;
        public MainForm()
        {
            InitializeComponent();
            _usuarioServices = new UsuarioServices();
            _usuarioValidator = new UsuarioValidator();
        }

        private void btnAgregarUsuario_Click(object sender, EventArgs e)
        {
            Usuario nuevoUsuario = new Usuario
            {
                NombreUsuario = txtNombreUsuario.Text,
                Apellido = txtApellido.Text,
                Carnet = txtCarnet.Text,
                Contraseña = txtContraseña.Text
            };

            var resultadoValidacion = _usuarioValidator.Validate(nuevoUsuario);

            if (!resultadoValidacion.IsValid)
            {
                string errores = string.Join(Environment.NewLine, resultadoValidacion.Errors);
                MessageBox.Show(errores, "Errores de validación", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            _usuarioServices.AddUsuario(nuevoUsuario);

            MessageBox.Show("Usuario agregado exitosamente.", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);

            LimpiarCampos();

        }
        private void LimpiarCampos()
        {
            txtNombreUsuario.Clear();
            txtApellido.Clear();
            txtCarnet.Clear();
            txtContraseña.Clear();
        }
    }
}
