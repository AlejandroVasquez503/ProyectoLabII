﻿namespace PresentationLayer.Forms
{
    partial class GastosForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            labelGastos = new Label();
            labelMonto = new Label();
            groupBox1 = new GroupBox();
            labelDescripción = new Label();
            labelUsuario = new Label();
            cmbUsuario = new ComboBox();
            label1 = new Label();
            labelFecha = new Label();
            dtpFecha = new DateTimePicker();
            txtMonto = new TextBox();
            txtDescripcion = new TextBox();
            cmbCategoria = new TextBox();
            btnAgregar = new Button();
            btnEditar = new Button();
            btnEliminar = new Button();
            dgvGastos = new DataGridView();
            errorProviderGastos = new ErrorProvider(components);
            groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgvGastos).BeginInit();
            ((System.ComponentModel.ISupportInitialize)errorProviderGastos).BeginInit();
            SuspendLayout();
            // 
            // labelGastos
            // 
            labelGastos.AutoSize = true;
            labelGastos.Font = new Font("Segoe UI", 13.8F, FontStyle.Italic, GraphicsUnit.Point, 0);
            labelGastos.Location = new Point(475, 24);
            labelGastos.Name = "labelGastos";
            labelGastos.Size = new Size(141, 31);
            labelGastos.TabIndex = 0;
            labelGastos.Text = "Editar Gastos";
            // 
            // labelMonto
            // 
            labelMonto.AutoSize = true;
            labelMonto.Font = new Font("Segoe UI", 10.8F, FontStyle.Italic, GraphicsUnit.Point, 0);
            labelMonto.Location = new Point(31, 51);
            labelMonto.Name = "labelMonto";
            labelMonto.Size = new Size(63, 25);
            labelMonto.TabIndex = 1;
            labelMonto.Text = "Monto";
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(txtDescripcion);
            groupBox1.Controls.Add(cmbCategoria);
            groupBox1.Controls.Add(txtMonto);
            groupBox1.Controls.Add(dtpFecha);
            groupBox1.Controls.Add(labelFecha);
            groupBox1.Controls.Add(label1);
            groupBox1.Controls.Add(cmbUsuario);
            groupBox1.Controls.Add(labelUsuario);
            groupBox1.Controls.Add(labelDescripción);
            groupBox1.Controls.Add(labelMonto);
            groupBox1.Location = new Point(70, 70);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(998, 332);
            groupBox1.TabIndex = 2;
            groupBox1.TabStop = false;
            groupBox1.Text = "groupBox1";
            // 
            // labelDescripción
            // 
            labelDescripción.AutoSize = true;
            labelDescripción.Font = new Font("Segoe UI", 10.8F, FontStyle.Italic, GraphicsUnit.Point, 0);
            labelDescripción.Location = new Point(21, 178);
            labelDescripción.Name = "labelDescripción";
            labelDescripción.Size = new Size(103, 25);
            labelDescripción.TabIndex = 2;
            labelDescripción.Text = "Descripción";
            // 
            // labelUsuario
            // 
            labelUsuario.AutoSize = true;
            labelUsuario.Font = new Font("Segoe UI", 10.8F, FontStyle.Italic, GraphicsUnit.Point, 0);
            labelUsuario.Location = new Point(535, 52);
            labelUsuario.Name = "labelUsuario";
            labelUsuario.Size = new Size(90, 25);
            labelUsuario.TabIndex = 3;
            labelUsuario.Text = "Categoria";
            // 
            // cmbUsuario
            // 
            cmbUsuario.FormattingEnabled = true;
            cmbUsuario.Location = new Point(647, 178);
            cmbUsuario.Name = "cmbUsuario";
            cmbUsuario.Size = new Size(303, 28);
            cmbUsuario.TabIndex = 4;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 10.8F, FontStyle.Italic, GraphicsUnit.Point, 0);
            label1.Location = new Point(535, 177);
            label1.Name = "label1";
            label1.Size = new Size(72, 25);
            label1.TabIndex = 5;
            label1.Text = "Usuario";
            // 
            // labelFecha
            // 
            labelFecha.AutoSize = true;
            labelFecha.Font = new Font("Segoe UI", 10.8F, FontStyle.Italic, GraphicsUnit.Point, 0);
            labelFecha.Location = new Point(36, 265);
            labelFecha.Name = "labelFecha";
            labelFecha.Size = new Size(58, 25);
            labelFecha.TabIndex = 6;
            labelFecha.Text = "Fecha";
            // 
            // dtpFecha
            // 
            dtpFecha.Location = new Point(125, 265);
            dtpFecha.Name = "dtpFecha";
            dtpFecha.Size = new Size(303, 27);
            dtpFecha.TabIndex = 7;
            // 
            // txtMonto
            // 
            txtMonto.Location = new Point(125, 49);
            txtMonto.Name = "txtMonto";
            txtMonto.Size = new Size(303, 27);
            txtMonto.TabIndex = 8;
            // 
            // txtDescripcion
            // 
            txtDescripcion.Location = new Point(130, 178);
            txtDescripcion.Name = "txtDescripcion";
            txtDescripcion.Size = new Size(322, 27);
            txtDescripcion.TabIndex = 10;
            // 
            // cmbCategoria
            // 
            cmbCategoria.Location = new Point(647, 52);
            cmbCategoria.Name = "cmbCategoria";
            cmbCategoria.Size = new Size(303, 27);
            cmbCategoria.TabIndex = 9;
            // 
            // btnAgregar
            // 
            btnAgregar.Font = new Font("Segoe UI", 10.8F, FontStyle.Italic, GraphicsUnit.Point, 0);
            btnAgregar.Location = new Point(101, 417);
            btnAgregar.Name = "btnAgregar";
            btnAgregar.Size = new Size(114, 40);
            btnAgregar.TabIndex = 3;
            btnAgregar.Text = "Agregar";
            btnAgregar.UseVisualStyleBackColor = true;
            // 
            // btnEditar
            // 
            btnEditar.Font = new Font("Segoe UI", 10.8F, FontStyle.Italic, GraphicsUnit.Point, 0);
            btnEditar.Location = new Point(512, 417);
            btnEditar.Name = "btnEditar";
            btnEditar.Size = new Size(114, 40);
            btnEditar.TabIndex = 4;
            btnEditar.Text = "Editar";
            btnEditar.UseVisualStyleBackColor = true;
            // 
            // btnEliminar
            // 
            btnEliminar.Font = new Font("Segoe UI", 10.8F, FontStyle.Italic, GraphicsUnit.Point, 0);
            btnEliminar.Location = new Point(860, 417);
            btnEliminar.Name = "btnEliminar";
            btnEliminar.Size = new Size(114, 40);
            btnEliminar.TabIndex = 5;
            btnEliminar.Text = "Eliminar";
            btnEliminar.UseVisualStyleBackColor = true;
            // 
            // dgvGastos
            // 
            dgvGastos.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvGastos.Location = new Point(89, 478);
            dgvGastos.Name = "dgvGastos";
            dgvGastos.RowHeadersWidth = 51;
            dgvGastos.Size = new Size(979, 205);
            dgvGastos.TabIndex = 6;
            // 
            // errorProviderGastos
            // 
            errorProviderGastos.ContainerControl = this;
            // 
            // GastosForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1193, 695);
            Controls.Add(dgvGastos);
            Controls.Add(btnEliminar);
            Controls.Add(btnEditar);
            Controls.Add(btnAgregar);
            Controls.Add(groupBox1);
            Controls.Add(labelGastos);
            Name = "GastosForm";
            Text = "GastosForm";
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dgvGastos).EndInit();
            ((System.ComponentModel.ISupportInitialize)errorProviderGastos).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label labelGastos;
        private Label labelMonto;
        private GroupBox groupBox1;
        private ComboBox cmbUsuario;
        private Label labelUsuario;
        private Label labelDescripción;
        private TextBox txtDescripcion;
        private TextBox cmbCategoria;
        private TextBox txtMonto;
        private DateTimePicker dtpFecha;
        private Label labelFecha;
        private Label label1;
        private Button btnAgregar;
        private Button btnEditar;
        private Button btnEliminar;
        private DataGridView dgvGastos;
        private ErrorProvider errorProviderGastos;
    }
}