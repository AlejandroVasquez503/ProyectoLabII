﻿namespace PresentationLayer.Forms
{
    partial class CategoriasForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            labelCategoria = new Label();
            cmbCategoria = new ComboBox();
            btnGuardarCategoria = new Button();
            errorProviderCategorias = new ErrorProvider(components);
            ((System.ComponentModel.ISupportInitialize)errorProviderCategorias).BeginInit();
            SuspendLayout();
            // 
            // labelCategoria
            // 
            labelCategoria.AutoSize = true;
            labelCategoria.Font = new Font("Segoe UI", 12F, FontStyle.Italic, GraphicsUnit.Point, 0);
            labelCategoria.Location = new Point(269, 25);
            labelCategoria.Name = "labelCategoria";
            labelCategoria.Size = new Size(192, 28);
            labelCategoria.TabIndex = 0;
            labelCategoria.Text = "Escoja una categoria";
            // 
            // cmbCategoria
            // 
            cmbCategoria.FormattingEnabled = true;
            cmbCategoria.Items.AddRange(new object[] { "Comida ", "Materiales", "Matricula ", "Transporte" });
            cmbCategoria.Location = new Point(224, 84);
            cmbCategoria.Name = "cmbCategoria";
            cmbCategoria.Size = new Size(275, 28);
            cmbCategoria.TabIndex = 1;
            // 
            // btnGuardarCategoria
            // 
            btnGuardarCategoria.Location = new Point(286, 147);
            btnGuardarCategoria.Name = "btnGuardarCategoria";
            btnGuardarCategoria.Size = new Size(153, 45);
            btnGuardarCategoria.TabIndex = 2;
            btnGuardarCategoria.Text = "Guardar Categoria";
            btnGuardarCategoria.UseVisualStyleBackColor = true;
            // 
            // errorProviderCategorias
            // 
            errorProviderCategorias.ContainerControl = this;
            // 
            // CategoriasForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(700, 258);
            Controls.Add(btnGuardarCategoria);
            Controls.Add(cmbCategoria);
            Controls.Add(labelCategoria);
            Name = "CategoriasForm";
            Text = "CategoriasForm";
            ((System.ComponentModel.ISupportInitialize)errorProviderCategorias).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label labelCategoria;
        private ComboBox cmbCategoria;
        private Button btnGuardarCategoria;
        private ErrorProvider errorProviderCategorias;
    }
}