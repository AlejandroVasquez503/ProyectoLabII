﻿using CommomLayer.Entities;
using DataAccessLayer.DbConnection;
using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccessLayer.Repositories
{
    public class GastoUniversitarioRepository
    {
        private readonly SqlDataAccess _dbAccess;

        public GastoUniversitarioRepository()
        {
            _dbAccess = new SqlDataAccess();
        }

        public List<GastoUniversitario> GetAllGastos()
        {
            using (var connection = _dbAccess.GetconnectionBD())
            {
                connection.Open();
                var query = "SELECT * FROM GastosUniversitarios";
                var command = new SqlCommand(query, connection);
                var reader = command.ExecuteReader();
                var gastos = new List<GastoUniversitario>();

                while (reader.Read())
                {
                    gastos.Add(new GastoUniversitario
                    {
                        IdGasto = (int)reader["IdGasto"],
                        Fecha = (DateTime)reader["Fecha"],
                        Monto = (decimal)reader["Monto"],
                        Descripcion = reader["Descripcion"].ToString(),
                        IdCategoria = (int)reader["IdCategoria"],
                        IdUsuario = (int)reader["IdUsuario"]
                    });
                }
                return gastos;
            }
        }

        public GastoUniversitario GetGastoById(int id)
        {
            using (var connection = _dbAccess.GetconnectionBD())
            {
                connection.Open();
                var query = "SELECT * FROM GastosUniversitarios WHERE IdGasto = @IdGasto";
                var command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@IdGasto", id);
                var reader = command.ExecuteReader();

                if (reader.Read())
                {
                    return new GastoUniversitario
                    {
                        IdGasto = (int)reader["IdGasto"],
                        Fecha = (DateTime)reader["Fecha"],
                        Monto = (decimal)reader["Monto"],
                        Descripcion = reader["Descripcion"].ToString(),
                        IdCategoria = (int)reader["IdCategoria"],
                        IdUsuario = (int)reader["IdUsuario"]
                    };
                }
                return null;
            }
        }

        public void InsertGasto(GastoUniversitario gasto)
        {
            using (var connection = _dbAccess.GetconnectionBD())
            {
                connection.Open();
                var query = "INSERT INTO GastosUniversitarios (Fecha, Monto, Descripcion, IdCategoria, IdUsuario) " +
                            "VALUES (@Fecha, @Monto, @Descripcion, @IdCategoria, @IdUsuario)";
                var command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@Fecha", gasto.Fecha);
                command.Parameters.AddWithValue("@Monto", gasto.Monto);
                command.Parameters.AddWithValue("@Descripcion", gasto.Descripcion);
                command.Parameters.AddWithValue("@IdCategoria", gasto.IdCategoria);
                command.Parameters.AddWithValue("@IdUsuario", gasto.IdUsuario);
                command.ExecuteNonQuery();
            }
        }

        public void UpdateGasto(GastoUniversitario gasto)
        {
            using (var connection = _dbAccess.GetconnectionBD())
            {
                connection.Open();
                var query = "UPDATE GastosUniversitarios SET Fecha = @Fecha, Monto = @Monto, Descripcion = @Descripcion, " +
                            "IdCategoria = @IdCategoria, IdUsuario = @IdUsuario WHERE IdGasto = @IdGasto";
                var command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@Fecha", gasto.Fecha);
                command.Parameters.AddWithValue("@Monto", gasto.Monto);
                command.Parameters.AddWithValue("@Descripcion", gasto.Descripcion);
                command.Parameters.AddWithValue("@IdCategoria", gasto.IdCategoria);
                command.Parameters.AddWithValue("@IdUsuario", gasto.IdUsuario);
                command.Parameters.AddWithValue("@IdGasto", gasto.IdGasto);
                command.ExecuteNonQuery();
            }
        }

        public void DeleteGasto(int id)
        {
            using (var connection = _dbAccess.GetconnectionBD())
            {
                connection.Open();
                var query = "DELETE FROM GastosUniversitarios WHERE IdGasto = @IdGasto";
                var command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@IdGasto", id);
                command.ExecuteNonQuery();
            }
        }
    }
}
