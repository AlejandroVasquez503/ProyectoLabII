﻿using Microsoft.Data.SqlClient;
using System.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccessLayer.DbConnection
{
    public class SqlDataAccess
    {
        private readonly string _connectionString;

        public SqlDataAccess()
        {
            _connectionString = "Data Source=ALEJANDRO\\SQLEXPRESS;Initial Catalog=ControlGastosUniversitarios;Integrated Security=True;Encrypt=False;Trust Server Certificate=True";
        }

        public SqlConnection GetconnectionBD()
        {
            return new SqlConnection(_connectionString);
        }
    }
}
